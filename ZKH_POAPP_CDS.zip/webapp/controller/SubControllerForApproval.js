sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Object, JSONModel, MessageToast) {

	"use strict";

	return Object.extend("kh.poappv.ZKH_POAPP_CDS.controller.SubControllerForApproval", {
		constructor: function(oParentView) {
			this._oParentView = oParentView;
			this._oResourceBundle = oParentView.getController().getResourceBundle();
			this._aPurchaseOrders = [];
			this._bApprove = false;
			this._fnApproveActionFinished = null;
			this._fnApproveFailed = null;
			this._oApprovalDialog = null;
			this._oApprovalProperties = null;
		},
		_initializeApprovalDialog: function() {
			this._oApprovalDialog = sap.ui.xmlfragment(this._oParentView.getId(), "kh.poappv.ZKH_POAPP_CDS.view.fragment.ApprovalDialog",
				this);
			jQuery.sap.syncStyleClass(this._oParentView.getController().getOwnerComponent().getContentDensityClass(), this._oParentView, this._oApprovalDialog);
			this._oParentView.addDependent(this._oApprovalDialog);
			this._oApprovalProperties = new JSONModel();
			this._oApprovalDialog.setModel(this._oApprovalProperties, "approvalProperties");
		},
		openDialog: function(bApprove, aPurchaseOrders) {
			var fnPromise = function(fnResolve, fnFailed) {
				// if (this._oGlobalModel.getProperty("/isBusyApproving"))
				if (this._oParentView.getProperty("busy")) {
					fnResolve(false);
					return;
				}
				var sApprovalText, sTitle;
				this._fnApproveActionFinished = fnResolve;
				this._fnApproveFailed = fnFailed;
				this._bApprove = bApprove;
				this._aPurchaseOrders = aPurchaseOrders;
				if (!this._oApprovalDialog) {
					this._initializeApprovalDialog();
				}
				if (aPurchaseOrders.length === 1) {
					sApprovalText = this._oResourceBundle.getText(this._bApprove ? "xfld.approvalTextWithSupplier" :
						"xfld.rejectionTextWithSupplier", [aPurchaseOrders[0].VendorName]);
					sTitle = this._oResourceBundle.getText(this._bApprove ? "xtit.approvalTitleForDialog" : "xtit.rejectionTitleForDialog");
				} else {
					return;
				}
				this._oApprovalProperties.setProperty("/approvalText", sApprovalText);
				this._oApprovalProperties.setProperty("/approvalTitle", sTitle);
				this._oApprovalProperties.setProperty("/approvalNote", "");
				this._oApprovalDialog.open();
			}.bind(this);
			return new Promise(fnPromise);
		},
		_cleanup: function() {
			this._oApprovalDialog.close();
			this._fnApproveFailed = null;
			this._aPurchaseOrders = null;
			this._fnApproveActionFinished = null;
		},
		onConfirmAction: function() {
			this._fnApproveActionFinished(true);
			var sApprovalNote = this._oApprovalProperties.getProperty("/approvalNote"),
				aPOIds = this._aPurchaseOrders.map(function(mPO) {
					return mPO.PurchaseOrder;
				}),
				oApprover = this._oParentView.getController().getOwnerComponent().oApprover,
				oWhenAppovalIsDone = oApprover.approve(this._bApprove, false, this._oParentView, aPOIds, sApprovalNote);

			oWhenAppovalIsDone.then(this._fnApproveActionFinished.bind(null, true), this._fnApproveFailed);
			this._cleanup();
			// MessageToast.show(this._oResourceBundle.getText("xbut.buttonOK"));
		},
		onCancelAction: function() {
			this._fnApproveActionFinished(false);
			this._cleanup();
			// MessageToast.show(this._oResourceBundle.getText("xbut.buttonCancel"));
		}
	});
});