sap.ui.define(["sap/ui/base/Object",
	"sap/ui/Device"
], function(Object, Device) {
	"use strict";
	return Object.extend("kh.poappv.ZKH_POAPP_CDS.model.Approver", {
		// This class provides the service of sending approve/reject requests to the
		// backend. Moreover, it deals with concurrent handling and success dialogs.
		// For this purpose, a single instance is created and attached to the
		// application.
		constructor: function(oListSelector) {

			this._oListSelector = oListSelector;
			this._iOpenCallsCount = 0;
			this._mRunningSwipes = {};
			this._bOneWaitingSuccess = false;

		},
		approve: function(bApprove, bFromSwipe, oView, aPOIds, sApprovalNote) {

			return new Promise(function(fnResolve, fnReject) {

				var sFunction = bApprove ? "/ApprovePurchaseOrder" : "/RejectPurchaseOrder",

					oModel = oView.getModel(),
					oGlobalModel = oView.getModel("globalProperties"),
					oResourceBundle = oView.getModel("i18n").getResourceBundle(),
					sSuccessMessage = "",
					sVendor = "";

				if (bFromSwipe) {
					// Note: Swipe approval is always single approval
					this._mRunningSwipes[aPOIds[0]] = true;
					oGlobalModel.setProperty("/isSwipeRunning", true);
				} else {
					oGlobalModel.setProperty("/isBusyApproving", true);
				}
				if (!Device.system.phone) {
					var sCurrentPOId = oGlobalModel.getProperty("/currentPOId"),
						bIsCurrentApproved = (sCurrentPOId === aPOIds[0]);
					if (bIsCurrentApproved) {
						this._oListSelector.prepareResetOfList(oGlobalModel);
					}
				}
				this._iOpenCallsCount++;

				var fnOnError = function() {
					this._callEnded(false, oGlobalModel);
					fnReject();
				}.bind(this);

				var fnOnSuccess = function() {

					this._callEnded(true, oGlobalModel);
					// A success message is only sent when the last request has
					// returned. Thus, when the user sends several requests via swipe,
					// only one
					// message toast is sent; this represents the request that came
					// back as last.

					if (this._iOpenCallsCount === 0) {
						if (aPOIds.length === 1) {
							sSuccessMessage = oResourceBundle.getText(bApprove ? "ymsg.approvalMessageToast" : "ymsg.rejectionMessageToast", [aPOIds[0]]);
							// sVendor = oModel.getProperty("/ZEWKM_PO_KHIL('" + aPOIds[0] + "')").VendorName;
							// sSuccessMessage = oResourceBundle.getText(bApprove ? "ymsg.approvalMessageToast" : "ymsg.rejectionMessageToast", [sVendor]);
						} else {
							sSuccessMessage = oResourceBundle.getText(bApprove ? "ymsg.massApprovalMessageToast" : "ymsg.massRejectionMessageToast");
						}
						sap.ui.require(["sap/m/MessageToast"], function(MessageToast) {
							MessageToast.show(sSuccessMessage);
						});
					}
					fnResolve();
				}.bind(this);
				if (aPOIds.length === 1) {
					oModel.callFunction(sFunction, {
						method: "POST",
						urlParameters: {
							POId: aPOIds[0],
							Note: sApprovalNote
						},
						success: fnOnSuccess,
						error: fnOnError
					});
				} else {
					for (var i = 0; i < aPOIds.length; i++) {
						oModel.callFunction(sFunction, {
							method: "POST",
							urlParameters: {
								POId: aPOIds[i],
								Note: sApprovalNote
							},
							batchGroupId: "POMassApproval",
							changeSetId: i
						});
					}
					oModel.submitChanges({
						batchGroupId: "POMassApproval",
						success: fnOnSuccess,
						error: fnOnError
					});
				}
			}.bind(this));
		},
		// Returns whether a swipe approval has been started for the
		// specified PO since the last refresh
		isSwipeApproving: function(sPOId) {
			return !!this._mRunningSwipes[sPOId];
		},
		// This method is called when a backend call for approve/reject has finished.
		// bSuccess states whether the call was successful
		// oGlobalModel is the global JSON model of the app

		_callEnded: function(bSuccess, oGlobalModel) {
			// Book-keeping:
			this._iOpenCallsCount--;
			this._bOneWaitingSuccess = bSuccess || this._bOneWaitingSuccess;

			if (this._iOpenCallsCount === 0) { // When we are not waiting for another call
				this._mRunningSwipes = {}; // start with a new round
				oGlobalModel.setProperty("/isSwipeRunning", false);
				oGlobalModel.setProperty("/isBusyApproving", false);
				if (this._bOneWaitingSuccess) {
					// At least one PO was approved/rejected successfully,
					this._bOneWaitingSuccess = false;
					this._oListSelector.refreshList();
					// Note that the busy approving state is reset when
					// the refresh is finished
				}
			}
		}
	});
});