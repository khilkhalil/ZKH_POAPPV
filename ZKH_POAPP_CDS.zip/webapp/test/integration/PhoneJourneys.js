/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/App",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Browser",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Master",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Detail",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "kh.poappv.ZKH_POAPP_CDS.view."
	});

	sap.ui.require([
		"kh/poappv/ZKH_POAPP_CDS/test/integration/NavigationJourneyPhone",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/NotFoundJourneyPhone",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});