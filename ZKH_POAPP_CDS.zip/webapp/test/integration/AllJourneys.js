/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 ZEWKM_PO_KHIL in the list
// * All 3 ZEWKM_PO_KHIL have at least one to_Item

sap.ui.require([
	"sap/ui/test/Opa5",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/App",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Browser",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Master",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/Detail",
	"kh/poappv/ZKH_POAPP_CDS/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "kh.poappv.ZKH_POAPP_CDS.view."
	});

	sap.ui.require([
		"kh/poappv/ZKH_POAPP_CDS/test/integration/MasterJourney",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/NavigationJourney",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/NotFoundJourney",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/BusyJourney",
		"kh/poappv/ZKH_POAPP_CDS/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});