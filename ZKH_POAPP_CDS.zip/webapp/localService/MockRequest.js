sap.ui.define(["sap/ui/base/Object"], function(Object) {
	"use strict";

	return Object.extend("kh.poappv.ZKH_POAPP_CDS.localService.MockRequests", {

		constructor: function(oMockServer) {
			// service URL -> to be replaced
			this._srvUrl = "/sap/opu/odata/sap/ZKH_PO_APV_SRV/";
			this._bError = false; //true if a this._sjax request failed
			this._sErrorTxt = ""; //error text for the oXhr error response
			this._oMockServer = oMockServer;
		},

		getRequests: function() {
			return [
				this.mockApprovePo(),
				this.mockRejectPo()
			];
		},

		mockApprovePo: function() {

			return {
				// This mock request simulates the function import
				// "ApprovePurchaseOrder", which is triggered when the
				// user chooses the "Approve" button.
				// It removes the approved purchase order from the mock
				// data.
				method: "POST",
				path: new RegExp("ApprovePurchaseOrder\\?POId='(.*)'&Note='(.*)'"),
				response: this.deletePo.bind(this)
			};
		},

		mockRejectPo: function() {

			return {
				// This mock request simulates the function import
				// "RejectPurchaseOrder",
				// which is triggered when the user chooses the "Reject"
				// button.
				// It removes the rejected purchase order from the mock
				// data.
				method: "POST",
				path: new RegExp("RejectPurchaseOrder\\?POId='(.*)'&Note='(.*)'"),
				response: this.deletePo.bind(this)
			};
		},

		deletePo: function(oXhr, sPOId, sNote) {
			var aPurchaseOrders = this._oMockServer.getEntitySetData("ZEWKM_PO_KHIL"),
				aPurchaseOrderItems = this._oMockServer.getEntitySetData("ZEWKM_PO_ITM"),
				filterPurchaseOrder = function(oPurchaseOrderOrPOItem) {
					return oPurchaseOrderOrPOItem.POId !== sPOId;
				};
			//removes the approved/rejected PurchaseOrders and

			// PurchaseOrderItems from the entity set data
			aPurchaseOrders = aPurchaseOrders.filter(filterPurchaseOrder.bind(this));
			this._oMockServer.setEntitySetData("ZEWKM_PO_KHIL", aPurchaseOrders);
			aPurchaseOrderItems = aPurchaseOrderItems.filter(filterPurchaseOrder.bind(this));
			this._oMockServer.setEntitySetData("ZEWKM_PO_ITM", aPurchaseOrderItems);
			oXhr.respondJSON(200, {}, JSON.stringify({
				d: {
					results: []
				}
			}));
		}
	});
});